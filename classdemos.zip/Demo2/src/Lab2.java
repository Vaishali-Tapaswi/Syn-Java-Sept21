interface Connection{
	void open();
	void close();
	default void describe() {
		System.out.println("in Connection Describe");
	}
}
interface Transaction{
	void begin();
	void commit();
	default void describe() {
		System.out.println("in Transaction Describe");
	}
}
class CommonImpl implements Connection, Transaction{

	@Override
	public void begin() {
		System.out.println("CommonImple - begin");	
	}

	@Override
	public void commit() {
		System.out.println("CommonImple - commit");
	}

	@Override
	public void open() {
		System.out.println("CommonImple - open");
	}

	@Override
	public void close() {
		System.out.println("CommonImple - close");
	}

	@Override
	public void describe() {
	System.out.println("CommonImpl - describe method - overriden");
	}
	
}
public class Lab2 {
public static void main(String[] args) {
		Connection con = new CommonImpl();
		con.open();
		con.close();
		con.describe();
		Transaction tx = new CommonImpl();
		tx.begin();
		tx.commit();
		con.describe();
}
}
