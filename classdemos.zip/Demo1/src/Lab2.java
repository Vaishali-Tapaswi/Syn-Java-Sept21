@FunctionalInterface
interface Process{
	int add(int no1, int no2);
}

public class Lab2 {

	public static void main(String[] args) {
		Process processImpl1 =   (int no1, int no2)  -> {
			return no1+no2;
		};
		Process processImpl2 =   (i, j)  ->  i+j;
		System.out.println(" add(100, 200) returned " + processImpl1.add(100, 200));
		System.out.println(" add(1000, 200) returned " + processImpl2.add(100, 200));
		
	}

}
