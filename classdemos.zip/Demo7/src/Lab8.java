import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Lab8 {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Anita", "Vaishali", "Sonali", "Simran", "Vishal", "Aman", "Shree", "Dyna");
		System.out.println(names);
		System.out.println("----------------");
		Optional<String> str= names.stream().reduce((a,b)->a+b);
		System.out.println(str.get());
	

	    List < Integer > numList = Arrays.asList(1, 4,5,10,20);
	    Optional<Integer> oint = numList.stream().reduce((a,b)->a+b);
	    System.out.println("Sum = " + oint.get());
	    
	    Integer sum  = numList.stream().reduce(0,(a,b)->a+b);
	    System.out.println("Sum = " + sum);

	    Integer multi  = numList.stream().reduce(1,(a,b)->a*b);
	    System.out.println("Product = " + multi);
	    
	}

}
