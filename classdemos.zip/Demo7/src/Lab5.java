import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Lab5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = EmpManager.getList(20);
		Optional<Emp> empop = list.stream().findAny();
		System.out.println(empop.get());
		System.out.println("\n\n");
    	empop=	 list.stream()
			.peek(e->System.out.println("before filter " + e))
			.filter((e)->e.getProject().equals("proj1"))
			.findAny();
		System.out.println("proj1 findany " +  empop.get());
		System.out.println("\n\n");
	    		boolean ans = list.stream()
				.peek(e->System.out.println("before filter " + e))
				.anyMatch((e)->e.getEname().equals("Vaishali") && e.getDept().equals("Sales"));
		System.out.println("Vaishali in FIn department is available : " + ans);
	}
}
