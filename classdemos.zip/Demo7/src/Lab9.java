import java.util.List;
import java.util.Optional;

public class Lab9 {
public static void main(String[] args) {
		List<Emp> list = EmpManager.getList(20);
	
	  System.out.println("########################");
	  list.stream().filter(e -> e.getDept().equals("HR")).forEach(System.out::println);

	  Double sumOfSalary = 
			  list.stream().filter(e -> e.getDept().equals("HR"))
			  	.map(e -> e.getSalary()).reduce(0.0,(a, b) -> a + b);
	  System.out.println("Sum of salaries for employees working in HR department: " + sumOfSalary);
	}

}
