import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lab7 {

	public static void main(String[] args) {
		List<String> names=Arrays.asList("Anita","Vaishali","Sonali", "Simran","Vishal","Aman","Shree","Dyna");
		
		names.stream().forEach(System.out::println);
		System.out.println("----------------");
		names.stream().map(str -> str.toUpperCase()).forEach(System.out::println);
		
		names.stream().map(str->str.length()).forEach(System.out::println);
	
		List<Integer> lengthofnames = names.stream().map(str->str.length()).collect(Collectors.toList());
		System.out.println(names);
		System.out.println(lengthofnames);
		
		List<Emp> list = EmpManager.getList(20);
		List<String> empList = list.stream()
				.map(emp-> emp.getEmpno()+","+emp.getEname()+","+emp.getSalary())
				.collect(Collectors.toList());
		empList.forEach(System.out::println);

		
	}

}
