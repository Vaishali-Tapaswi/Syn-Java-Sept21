import java.util.List;
import java.util.Scanner;

public class Lab6 {
	public static void main(String[] args) {

		List<Emp> list = EmpManager.getList(100);
		Scanner s = new Scanner(System.in);
		int i = 0;
		while(i < 100) {
		//for (int i = 0; i < 100; i = i + 10) {
			list.stream().skip(i).limit(10).forEach(System.out::println);

			System.out.println("To continue press 'p' or for termination press 'n' and press 'e' for exit");
			String c = s.next();
			if (c.equals("e")) {
				System.out.println("pressed exit, closing");
				break;
			}
			if (c.equals("n")) {
				System.out.println("pressed n");
				i += 10;
			} else {
				System.out.println("pressed p");
				i -= 10;
			}
		}

	}

}
