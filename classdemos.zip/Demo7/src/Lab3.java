import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Lab3 {

		  public static void main(String[] args) {

		    List < Integer > numList = Arrays.asList(4, 10, 59, 10, 3, 111, 8, 9, 14, 67, 15, 12, 1, 133, 2);

		    System.out.println("########## 1. Show numbers ############");
		    numList.forEach(System.out::println);

		    System.out.println("######### 2. Sorted - Natural sorting ##########");
		    numList.stream().sorted().forEach(System.out::println);
		    System.out.println("######### 2. Sorted - Natural sorting ##########");
		    numList.stream().sorted(Integer::compare).forEach(System.out::println);
		
		    System.out.println("######### 3. Min ##########");
		    Optional<Integer> min = numList.stream().min(Integer::compare);
		    System.out.println(min.get());

		    System.out.println("######### 4. Max ##########");
		    Optional < Integer > max = numList.stream().max((I1, I2) -> I1 > I2 ? 0 : -1);
		    System.out.println(max.get());

		    System.out.println("######### 5. Show all where number > 50 ##########");
		    numList.stream().filter(num->num > 50).forEach(System.out::println);
		    System.out.println("#########6. Show all where number is between 10 and 50 (2 filters) ##########");
		    numList.stream().filter(num->num > 10).filter(num->num<50).forEach(System.out::println);
			
		    System.out.println("#########7. Show all where number is between 10 and 50 (1 filters as and condition)	 ##########");
		    numList.stream().filter(num->num > 10 && num<50).forEach(System.out::println);
				
			
}
}
