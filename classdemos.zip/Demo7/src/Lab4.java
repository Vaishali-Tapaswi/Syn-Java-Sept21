import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Lab4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = EmpManager.getList(20);
		   System.out.println("########## 1. Show All records ############");
		   list.forEach(System.out::println);
		//   list.stream().forEach(System.out::println);
		   System.out.println("######### 2. Sorted - based on Ename  ##########");
		   list.stream().sorted((x,y)->x.getEname().compareToIgnoreCase(y.getEname())).forEach(System.out::println);
		   System.out.println("######### 2. Sorted - based on Salary ##########");
		   Comparator<Emp> salarycomp = (x,y)->Double.compare(x.getSalary(), y.getSalary());
		    list.stream().sorted(salarycomp).forEach(System.out::println);
		
		   System.out.println("######### 3. Show Emp with  Min Salary ##########");
		   Optional<Emp> minSalary= list.stream().min((x,y)->Double.compare(x.getSalary(), y.getSalary()));
		   System.out.println(" Minimum Salary : "+minSalary.get().getSalary());
		  
		   System.out.println("######### 4. Show Emp with Project 'proj1' having Min Salary ##########");
		   Optional<Emp> projectAndMinSal= list.stream().filter((emp)->emp.getProject().equalsIgnoreCase("proj1")).min((x,y)->Double.compare(x.getSalary(), y.getSalary()));
		   System.out.println("Project Name  : "+ projectAndMinSal.get().getProject() + " Minimum Salary : "+projectAndMinSal.get().getSalary());
		  
		   System.out.println("######### 5. Show Emp with department as 'IT' and project as 'proj2' ##########");
		   list.stream().filter((empObj)-> empObj.getDept().equalsIgnoreCase("IT") && empObj.getProject().equalsIgnoreCase("proj2")).forEach(System.out::println);

		
		    System.out.println("#########6. Number of employees in 'L&D' department ##########");
		    long count = list.stream().filter((empObj)-> empObj.getDept().equalsIgnoreCase("L&D")).count();
		    System.out.println("Total Number employees for L&D " + count);

	}

}
