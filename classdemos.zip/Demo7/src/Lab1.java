import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Lab1 {

	public static void main(String[] args) {
		List<String> names=Arrays.asList("Anita","Vaishali","Sonali", "Simran","Vishal","Aman","Shree","Dyna");
		
		Stream<String> strstream = Stream.of("Anita","Vaishali","Sonali", "Simran","Vishal","Aman","Shree","Dyna");
		strstream.forEach(System.out::println);
		System.out.println("----------------");
	//	strstream.forEach(System.out::println);
		names.stream().forEach(System.out::println);
		System.out.println("----------------");
		
	}

}
