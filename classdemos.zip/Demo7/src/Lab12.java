import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Lab12 {
	 // Driver code
    public static void main(String[] args)
    {
    	List<String> list1 = Arrays.asList("1", "2", "3","4" );
    	 List<String> list2 = Arrays.asList("11", "22", "33" );
    	 List<String> list3 = Arrays.asList("111", "222", "333","444","555","666" );
    	 List<List<String>> list = new ArrayList<List<String>>();
    	 list.add(list1);
    	 list.add(list2);
    	 list.add(list3);
  //  	 list.stream().forEach(System.out::println);
    	 list.stream().map(l->l.size()).forEach(System.out::println);
    	 System.out.println("------------------");
    	 list.stream().flatMap(l->l.stream()).forEach(System.out::println);
			/*
			 * 
			 * 
			 * // Creating a List of Strings List<String> list = Arrays.asList("5.6", "7.4",
			 * "4", "1", "2.3");
			 * 
			 * list.stream().map(str -> Double.parseDouble(str)).
			 * forEach(System.out::println); System.out.println("-----------"); // Using
			 * Stream flatMap(Function mapper) list.stream().flatMap(num -> Stream.of(num)).
			 * forEach(System.out::println);
			 * 
			 */   }
}
