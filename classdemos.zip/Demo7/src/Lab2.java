import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Lab2 {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Anita", "Vaishali", "Sonali", "Simran", "Vishal", "Aman", "shree", "Dyna");
		names.stream().forEach(System.out::println);
		// show all records where name ends with li
		System.out.println("-----------------Names ending with li----------------");
		names.stream().filter((str) -> str.endsWith("li")).forEach(System.out::println);
		// show all records where name starts with s
		System.out.println("-----------------Names starts with S----------------");
		names.stream().filter((str) -> str.startsWith("S")).forEach(System.out::println);
		// forEach -> Terminal 
		// filter -> intermediate
		System.out.println("--------------------Sorted Output for name contains sh---------------------------");
		names.stream().filter(s->s.contains("sh")).sorted().forEach(System.out::println);
		
		
	}

}
