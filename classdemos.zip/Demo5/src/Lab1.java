import java.util.Date;

public class Lab1 {
public static void main(String[] args) {
	Date d1 = new Date();
	System.out.println("Date = " + d1);
	System.out.println("Date = " + new java.sql.Date(d1.getTime()));
}
}
