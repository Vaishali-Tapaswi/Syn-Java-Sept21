import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.IntPredicate;
import java.util.function.IntUnaryOperator;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

//1. Need of declaring calc interface
/*
 * @FunctionalInterface
 
interface Calc {
	int operation(int a, int b );
}

interface Convert {
	double converttoRs(int amt, String fromc);
}
*/
public class Lab2 {
	public static void main(String[] args) {
	
		BiFunction<Integer,Integer,Integer>  calcadd = (x,y)->x+y;
		BinaryOperator<Integer> calcsub = (x,y)->x-y;
		
		BiFunction<Integer,String,Double> convertoRs = (amt,fromc)->{
			if (fromc.equals("$"))
				return amt*70.0;
			if (fromc.equals("Yen"))
				return amt * 10.0;
			return 0.0;
		};
		
		System.out.println(" add with 10,20 returned " + calcadd.apply(10,20) );
		System.out.println(" sub with 10,20 returned " + calcsub.apply(10,20) );
		System.out.println(" Convert for $  returned " + convertoRs.apply(10,"$") );
		System.out.println(" Convert for Yen returned " + convertoRs.apply(10,"Yen") );
		System.out.println(" Convert for NA  returned " + convertoRs.apply(10,"NA") );
			
		    // find sqare
	  //      Function < Integer, Integer > sq = no1 -> no1 * no1;
	  //      UnaryOperator<Integer> sq = no1 ->no1*no1;
	        IntUnaryOperator sq = no1 ->no1*no1;
	        System.out.println("The square of the variable: " + sq.applyAsInt(10));
	        IntPredicate odd =  no1 -> no1 % 2 != 0;
	       System.out.println("The number is odd : " + odd.test(10));
	       System.out.println("The number is odd : " + odd.test(5));


	        //Consumer<String> print = s -> System.out.println(s);
	       Consumer<String> print = System.out::println;
	        print.accept("This is my new String to print");

	        //int genrandomnum()

	        Supplier<Long> ran = () ->  ((long)Math.random())*100;
	         System.out.println("The random number is: " + ran.get());

	    }

	}
