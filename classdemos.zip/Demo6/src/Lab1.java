import java.time.LocalDate;
import java.util.Scanner;

public class Lab1 {
  public static void main(String[] args) {  
	System.out.println("Enter the year");
	Scanner sc1=new Scanner(System.in);
	int enteredYear=sc1.nextInt();
    
	System.out.println("Enter the month");
	Scanner sc2=new Scanner(System.in);
	int enteredMonthe=sc2.nextInt();
	
	System.out.println("Enter the date");
	Scanner sc3=new Scanner(System.in);
	int enteredDate=sc3.nextInt();
	
	LocalDate date = LocalDate.of(enteredYear, enteredMonthe, enteredDate);
    
    System.out.println("the finaldate is"+date);  
   
   }  
}
