import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class Dept {
	private int deptno;
	private String dname;
	private String loc;

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", loc=" + loc + "]";
	}
}

class DeptDAO {
	List<Dept> list = new ArrayList<Dept>();

	public void add(Dept d) {
		list.add(d);
	}

	public List<Dept> list() {
		return list;
	}

	public Optional<Dept> get(int deptno) {
		for (Dept dept : list) {
			if (dept.getDeptno() == deptno)
				return Optional.of(dept);
		}
		return Optional.ofNullable(null);
	}
}
public class Lab3 {
public static void main(String[] args) {
	DeptDAO dao = new DeptDAO();
	for (int i = 10;i< 50;i+=10)
	{
			Dept d= new Dept();
			d.setDeptno(i);
			d.setDname("Dnameof"+i);
			if ( (i%20)==0)
					d.setLoc("Hyd");
			else
					d.setLoc("Pune");
			dao.add(d);
	}
	dao.list().forEach(System.out::println);
 	Optional<Dept> d = dao.get(10);
 	if (d.isPresent())
 			System.out.println("Dept of 10 is " + d.get());
 	else
 			System.out.println("Department Not Found");
}
}

