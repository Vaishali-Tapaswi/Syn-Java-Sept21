import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class EmpManager implements Manager<Emp> {

	private List<Emp> list = new ArrayList<>();


	@Override
	public List<Emp> getList() {
		return list;
	}

	public void update(Emp t) {
		for (Emp emp : list) {
			if (emp.getEmpno() == t.getEmpno()) {
				emp.setEname(t.getEname());
				emp.setSalary(t.getSalary());
				break;
			}
		}
	}

	public static void main(String[] args) {
		
		System.out.println("Press a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		EmpManager mgr = new EmpManager();
		for (int i = 1; i < 10000; i += 1) {
			Emp d = new Emp();
			d.setEmpno(i);
			d.setEname("Nameof" + i);
			d.setSalary(i * 1000);
			mgr.insert(d);
		}
		mgr.getList().forEach(System.out::println);
		System.out.println("\n\n");
		Emp d = new Emp();
		d.setEmpno(1);
		d.setEname("Vaishali");
		d.setSalary(10000);
		mgr.update(d);
		
		mgr.delete((e1)->e1.getSalary()>5000);
		mgr.getList().forEach(System.out::println);
	}

}