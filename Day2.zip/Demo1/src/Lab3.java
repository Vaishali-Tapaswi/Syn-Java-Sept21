@FunctionalInterface
interface Calc {
	int operation(int a, int b );
}
public class Lab3 {
	public static void main(String[] args) {
		Calc add = (a,b)-> a+b;
		Calc sub = (a,b)->a-b;
		Calc mult = (a,b)->a*b;
		
		System.out.println(" add with 10,20 returned " + add.operation(10,20) );
		
	}
}
