//1. Need of declaring calc interface
@FunctionalInterface
interface Calc {
	int operation(int a, int b );
}
interface Convert {
	int converttoRs(int dl, int covrate);
}
public class Lab1 {
	public static void main(String[] args) {
		int dtor= 70;
		Convert dtorConvert = (amt,conrate)->{
			conrate+=10;
			return amt*conrate;
		};
		dtor = 55;
	//	Convert dtorConvert1 = (amt)-> amt*dtor;
		System.out.println("Invoke conversion  = " + dtorConvert.converttoRs(10,dtor));
		
		
		Calc add = (a,b)-> a+b;
		Calc sub = (a,b)->a-b;
		Calc mult = (a,b)->a*b;
	
		System.out.println(" add with 10,20 returned " + add.operation(10,20) );
		
	}
}
