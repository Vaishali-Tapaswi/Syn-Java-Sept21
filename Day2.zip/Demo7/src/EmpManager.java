import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class EmpManager {

	private static List<Emp> list = new ArrayList<>();


	public static List<Emp> getList(int no) {
		List<String> names=Arrays.asList("Anita","Vaishali","Sonali", "Simran","Vishal","Aman","Shree","Dyna");
		List<String> depts = Arrays.asList("HR","IT","Fin","L&D","Sales");
		List<String> projects = Arrays.asList("proj1", "proj2","proj3");
		for (int i = 1; i < no; i += 1) {
			Emp e = new Emp();
			e.setEmpno(i);
			e.setEname(names.get(i % names.size()));
			e.setDept(depts.get(i%depts.size()));
			e.setProject(projects.get(i % projects.size()));
			e.setSalary((int)(Math.random()*1000));
			list.add(e);
		}
		return list;
	}
	public static void main(String[] args) {
		EmpManager.getList(20).forEach(System.out::println);
	}

}