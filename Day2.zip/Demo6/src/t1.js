print('Hello World from t1.js!!');
