import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Lab2 {
public static void main(String[] args) throws Exception {
	String script =  "print('Hello World !!')";
	// load t1.js file and pass the content for eval
	ScriptEngine engine = new  ScriptEngineManager().getEngineByName("nashorn");
	 Object result = engine.eval(script);
	 FileReader fr=new FileReader(Lab2.class.getResource("./t1.js").getFile());    
	 result = engine.eval(fr);
}
}
